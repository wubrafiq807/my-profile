import React from "react";
import ListGroup from "react-bootstrap/ListGroup";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import SideNavPage from "./components/organisms/SideNavPage.jsx";

export default class Header extends React.Component {
  render() {
    return (
      <Container>
        <Row></Row>
      </Container>
    );
  }
}
